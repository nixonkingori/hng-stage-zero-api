package com.hng.stagezeroapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StageZeroApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
